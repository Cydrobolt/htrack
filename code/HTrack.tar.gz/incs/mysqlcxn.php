<?php
require("ht-config.php");
$cxn = mysqli_connect($host,$user,$passwd,$db) or die("Connection required, will now exit");
?>
