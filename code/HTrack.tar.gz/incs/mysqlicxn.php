<?php
require("/incs/ht-config.php");
$mysqli = new mysqli($host,$user,$passwd,$db) or die("Connection required, will now exit");
?>
