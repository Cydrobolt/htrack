<?php

$host = "localhost";
$user = "usr";
$passwd = "browser";
$db = "htrack";
$logoloc = "/incs/default.png";
$contacteml = "help@yourcompany.com";
$msgifdenied = "";
?>
