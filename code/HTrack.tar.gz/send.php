<html>
<head>
   <?php include("dotrack.php"); ?> 
    <?php include("scan.php");?>
</head>
<body>

    <!--Site Content-->
    Site content
</body>
</html>